# PhantomLink — Phantom Mascot Pack

This ZIP contains the approved Phantom visual direction, eight pose/expression exports,
app and favicon assets, and a small reusable React / Next.js component.

## Contents
- `public/phantom/` — PNG/WebP pose assets, icon variants, favicon sizes and ICO.
- `src/components/Phantom.tsx` — reusable expression-driven Next.js component.
- `src/components/phantom.css` — float animation, glow treatments and reduced-motion support.
- `docs/INTEGRATION.md` — setup and usage instructions.
- `docs/phantom-approved-character-board.png` — approved character concept board.
- `docs/phantomlink-brand-integration-concept.png` — visual integration concept.

## Important production note
This is a ready-to-integrate starter asset pack, not a final 3D source package. The pose images
are extracted from the approved presentation board and therefore inherit its lighting/background
rendering and small-sheet limitations. They are not independently rendered from a shared master
3D rig. The pack does not modify your live PhantomLink repository. Provide the GitHub repository
or project ZIP for a project-specific integration and validation pass.
