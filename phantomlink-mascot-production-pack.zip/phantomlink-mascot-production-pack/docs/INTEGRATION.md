# PhantomLink mascot integration (Next.js)

## 1. Copy the assets
Copy the contents of `public/phantom/` into your project's `public/phantom/` directory.
Copy `src/components/Phantom.tsx` and `src/components/phantom.css` into your project.
If your project uses a different source directory, adjust the import path only.

## 2. Use the component
```tsx
import Phantom from "@/components/Phantom";

export default function Hero() {
  return (
    <section className="hero">
      <div>
        <h1>Bring legacy systems back to life.</h1>
        <p>Connect. Verify. Transact.</p>
      </div>
      <Phantom expression="default" size={320} priority />
    </section>
  );
}
```

## 3. Change expressions from application state
```tsx
<Phantom expression="working" size={96} />
<Phantom expression="excited" size={120} />
<Phantom expression="warning" size={88} animated={false} />
```

Supported expressions: `default`, `curious`, `working`, `excited`, `sleeping`,
`warning`, `resurrection`, `celebrating`.

## 4. Set the favicon (App Router)
In `src/app/layout.tsx`, add or update metadata:
```tsx
export const metadata = {
  icons: {
    icon: [
      { url: "/phantom/favicon-16.png", sizes: "16x16", type: "image/png" },
      { url: "/phantom/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/phantom/favicon-48.png", sizes: "48x48", type: "image/png" },
    ],
    apple: "/phantom/favicon-180.png",
  },
};
```
Alternatively, place `favicon.ico` at `src/app/favicon.ico`.

## 5. Integration guidance
- Use `default` in the homepage hero and brand moments.
- Use `working` during device discovery, verification, or background processing.
- Use `excited` after successful verification.
- Use `warning` for recoverable connection failures; pair it with clear text and never rely on colour alone.
- Use `sleeping` for empty or idle states.
- Use `resurrection` for a successful legacy-device wake-up moment.
- Keep mascot presentation separate from connection, verification, payment, and dashboard logic.
- Do not animate essential status information. The component disables its float animation when the OS requests reduced motion.
- Prefer WebP for web delivery; keep PNGs for design tools and fallback use.

## 6. Before shipping
The supplied pose exports are crops from the approved concept presentation board. They are useful as a first integration kit, but they are not eight independently rendered production poses from one locked 3D model. For a final commercial-grade asset family, commission or create a single master 3D model and render all poses, views, and transparent outputs from that same model. Review the favicon at 16px on both light and dark browser chrome.
