"use client";

import Image from "next/image";
import "./phantom.css";

export type PhantomExpression =
  | "default"
  | "curious"
  | "working"
  | "excited"
  | "sleeping"
  | "warning"
  | "resurrection"
  | "celebrating";

export interface PhantomProps {
  expression?: PhantomExpression;
  size?: number | string;
  alt?: string;
  className?: string;
  animated?: boolean;
  priority?: boolean;
}

/**
 * Phantom mascot component.
 * Put the supplied /phantom assets in your Next.js public/phantom directory.
 * The component is intentionally independent of dashboard/business logic.
 */
export function Phantom({
  expression = "default",
  size = 220,
  alt = "Phantom, the PhantomLink spectral machine spirit",
  className = "",
  animated = true,
  priority = false,
}: PhantomProps) {
  const dimension = typeof size === "number" ? `${size}px` : size;
  return (
    <span
      className={[
        "phantom-mascot",
        animated ? "phantom-mascot--animated" : "",
        className,
      ].filter(Boolean).join(" ")}
      style={{ width: dimension, height: dimension }}
      data-expression={expression}
    >
      <Image
        src={`/phantom/phantom-${expression}.webp`}
        alt={alt}
        fill
        sizes="(max-width: 640px) 45vw, 220px"
        priority={priority}
        className="phantom-mascot__image"
      />
    </span>
  );
}

export default Phantom;
